package com.myapp.crmrestapi.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.myapp.crmrestapi.model.Course;
import com.myapp.crmrestapi.repository.CourseRepository;

@Service
public class CourseService {

	@Autowired
	CourseRepository courserepo;
	
	public List<Course> findAll() {
		return courserepo.findAll();
	}

	public Course save(Course course) {
		courserepo.save(course);
		if (course.getId() == -1 || course.getId() == 0) {
		//	course.setId(++idCounter);
			
		} 
		return course;
	}
	public Course update(Course course) {		
			courserepo.save(course);		 
		return course;
	}
	
	public Course deleteById(long id) {
		Optional<Course> course = courserepo.findById(id);

		if (course == null)
			return null;
		else 
		{
			courserepo.deleteById(id);			
		}
		return null;
	}
	
	public Optional<Course> FindById(long id) {
		return courserepo.findById(id);
	}

	
}
