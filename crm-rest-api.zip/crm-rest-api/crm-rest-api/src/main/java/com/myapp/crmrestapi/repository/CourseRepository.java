package com.myapp.crmrestapi.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.myapp.crmrestapi.model.Course;

@Repository
public interface CourseRepository extends JpaRepository<Course, Long >{
	List<Course> findByUsername(String username);
	
 	
}
