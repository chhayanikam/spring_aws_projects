package com.myapp.crmrestapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CrmRestApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
