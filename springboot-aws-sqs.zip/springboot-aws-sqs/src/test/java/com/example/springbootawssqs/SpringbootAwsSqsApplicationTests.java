package com.example.springbootawssqs;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootAwsSqsApplicationTests {

	@Test
	void contextLoads() {
	}

}
