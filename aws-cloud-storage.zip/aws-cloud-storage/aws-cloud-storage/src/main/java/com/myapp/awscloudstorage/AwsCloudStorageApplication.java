package com.myapp.awscloudstorage;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AwsCloudStorageApplication {

	public static void main(String[] args) {
		SpringApplication.run(AwsCloudStorageApplication.class, args);
	}

}
