package com.myapp.awscloudstorage;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AwsCloudStorageApplicationTests {

	@Test
	void contextLoads() {
	}

}
